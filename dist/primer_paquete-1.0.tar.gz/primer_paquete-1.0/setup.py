from setuptools import  setup

setup(
    name="primer_paquete",
    version="1.0",
    description="Creación del primer paquete redistribuible - 2da preentrega.",
    author="Waldo Gaspari",
    author_email="waldogaspari@gmail.com",

    packages=["primer_paquete"]
)